# PMD Objective-C

Only CPD is supported. There are no PMD rules for Objective-C.
