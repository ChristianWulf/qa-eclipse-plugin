@import UIKit;

// Please note: the first С of gNСServerLogonCertificate is U+0421
static SecCertificateRef gNСServerLogonCertificate;

@end
