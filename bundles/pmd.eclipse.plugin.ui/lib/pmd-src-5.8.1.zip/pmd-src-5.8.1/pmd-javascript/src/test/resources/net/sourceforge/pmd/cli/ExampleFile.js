/**
 * BSD-style license; for more info see http://pmd.sourceforge.net/license.html
 */
// just some js file for net.sourceforge.pmd.cli.CLITest
