# PMD Perl

Contains the PMD implementation to support the Perl programming language.

Only very basic CPD support is implemented currently.
