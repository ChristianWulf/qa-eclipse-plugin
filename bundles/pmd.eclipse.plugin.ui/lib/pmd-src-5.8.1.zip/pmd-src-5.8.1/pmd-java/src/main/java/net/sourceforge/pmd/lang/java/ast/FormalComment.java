/**
 * BSD-style license; for more info see http://pmd.sourceforge.net/license.html
 */

package net.sourceforge.pmd.lang.java.ast;

public class FormalComment extends Comment {

    public FormalComment(Token t) {
        super(t);
    }

}
