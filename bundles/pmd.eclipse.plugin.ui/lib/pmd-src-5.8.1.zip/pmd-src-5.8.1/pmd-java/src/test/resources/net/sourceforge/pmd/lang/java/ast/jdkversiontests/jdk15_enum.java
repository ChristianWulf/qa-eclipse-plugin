public class Test {
 enum Season { winter, spring, summer, fall };
}
