/**
 * BSD-style license; for more info see http://pmd.sourceforge.net/license.html
 */


package net.sourceforge.pmd.typeresolution.testdata.dummytypes;

public class SuperClassA extends SuperClassA2 {
    public SuperClassA s;
}
