public class Foo {
  void bar() { assert(); }
}