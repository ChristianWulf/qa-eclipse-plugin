public class Test {
  ArrayList<Integer> list =  new ArrayList<Integer>();
}