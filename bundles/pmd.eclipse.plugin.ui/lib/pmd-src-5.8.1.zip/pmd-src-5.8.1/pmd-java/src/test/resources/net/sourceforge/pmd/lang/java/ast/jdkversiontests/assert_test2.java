public class Foo {
 void bar() {
  assert (x == 2);
 }
}