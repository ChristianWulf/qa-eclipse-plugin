public class Foo {
  int assert = 2;
}