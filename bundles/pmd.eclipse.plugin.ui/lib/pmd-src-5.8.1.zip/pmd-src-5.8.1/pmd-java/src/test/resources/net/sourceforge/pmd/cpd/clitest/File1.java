public class File1 {
    public void dup() {
        for (int i = 0; i < 10; i++) {
            System.out.println(i + "ä");
        }
    }
}