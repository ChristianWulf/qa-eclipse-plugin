# PMD Scala

Only CPD is supported. There are no PMD rules for Scala.
