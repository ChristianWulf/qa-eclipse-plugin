Please, prefix the report title with the language it applies to within brackets, such as *[java]* or *[apex]*. If not specific to a language, you can use *[core]*

**Rule Set:**

**Description:**

**Code Sample demonstrating the issue:**

```

```

**Running PMD through:** *[CLI | Ant | Maven | Gradle | Designer | Other]*

