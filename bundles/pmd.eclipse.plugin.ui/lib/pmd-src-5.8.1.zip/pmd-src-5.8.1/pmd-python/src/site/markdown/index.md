# PMD Python

Only CPD is supported. There are no PMD rules for Python.
