public class Foo {
  public <T extends E> Foo() {}
}