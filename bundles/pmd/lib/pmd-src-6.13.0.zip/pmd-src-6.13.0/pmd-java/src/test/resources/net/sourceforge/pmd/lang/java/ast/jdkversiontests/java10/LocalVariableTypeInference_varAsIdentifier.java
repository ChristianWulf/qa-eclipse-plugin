public class LocalVariableTypeInference_varAsIdentifier {
    public static void main(String... args) {
        var var = 1;

        System.out.println("var = " + var);
    }
}
