public class Test {
  void bar() {
   final class Inner {};
   Inner i = new Inner();
  }
}