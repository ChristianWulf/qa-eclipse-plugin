public @interface Foo {
  String CONST = "foo";
}