public class Test {
  public static <String> String test(String x) {
   return x;
  }
}