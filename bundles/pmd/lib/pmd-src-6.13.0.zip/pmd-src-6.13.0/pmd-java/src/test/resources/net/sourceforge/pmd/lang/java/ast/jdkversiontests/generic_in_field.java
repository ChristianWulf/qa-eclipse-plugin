public class Foo {
 Class<Double> foo = (Class<Double>)clazz;
}