public class Test {
 void bar(Object ... args) {}
}