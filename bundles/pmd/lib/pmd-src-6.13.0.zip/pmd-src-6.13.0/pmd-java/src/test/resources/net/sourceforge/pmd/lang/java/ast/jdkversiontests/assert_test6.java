public class Foo {
 void foo() {
  assert (x == 2) : "hi!";
 }
}