public class InputJava7Multicatch {
 public static void main() {
  try { }
  catch (FileNotFoundException | CustomException e) { }
 }
}