public class GoodFile {
    public void foo() {
        int abc = 1;
    }
}