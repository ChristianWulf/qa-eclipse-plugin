public class Test {
 int enum;
}
