public class Test {
 void foo(List list) {
  for (final Integer i : list) {}
 }
}