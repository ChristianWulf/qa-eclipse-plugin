---
title: "Extending PMD"
tagName: extending
search: exclude
permalink: tag_extending.html
sidebar: pmd_sidebar
folder: tags
---
{% include taglogic.html %}
