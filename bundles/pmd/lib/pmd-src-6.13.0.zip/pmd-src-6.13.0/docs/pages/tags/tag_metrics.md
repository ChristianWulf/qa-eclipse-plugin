---
title: "Code metrics"
tagName: metrics
search: exclude
permalink: tag_metrics.html
sidebar: pmd_sidebar
folder: tags
---
{% include taglogic.html %}
